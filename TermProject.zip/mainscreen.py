#
#Main Scren Function, Creates UI and calls other files
#
#
#

import subprocess
import time
from tkinter import *
from multiinstrument import playMarkov
from visualizer import doPyGamestuff
import tkinter as tk
import math
from markov import Markov
import os
from xml.dom import minidom
from xmlParser import Parse
import string
from webScraping import search,download
from init import init as initfilesystem
from init import delete
#from multiInstrument import play


class Dicts(object):
    notesDict = {
                'a':('red',0),
                'b':('green',2*math.pi/8),
                'c':('blue',2*math.pi/4),
                'd':('orange',2*3*math.pi/8),
                'e':('yellow',2*math.pi/2),
                'f':('purple',2*5*math.pi/8),
                'g':('pink',2*6*math.pi/8),
                'r':('grey',2*7*math.pi/8),
                'p':('white',15*math.pi/8)
                }

class Circle(object):
    def __init__(self,note,octave,duration,tempo,data):
        self.tempo = tempo
        self.note = note[:1]
        self.octave = octave
        self.color = Dicts.notesDict[self.note][0]
        self.duration = duration
        self.x = data.width/2
        self.y = data.height/2
        self.angle = Dicts.notesDict[self.note][1]
    def move(self,canvas,data):
        canvas.create_oval(self.x,self.y,self.x+50,self.y+50,fill=self.color,width=0)
        self.x,self.y = self.x+2*math.cos(self.angle),self.y+2*math.sin(self.angle)

class Voice(object):
    def __init__(self,data,voice):
        self.tempo = data.tempo
        self.voice = voice
        self.x = data.width-data.width/3
        self.y = data.height/10 * (8-voice[0][2])-((
                            ord(voice[0][1])-97)%97)*(data.width/10 /7)
    def move(self,canvas,data):
        for item in self.voice[:1]:
            appearAfter = item[0]
            self.x = data.width-data.width/3
            if(appearAfter<data.pointInSong):
                note = item[1]
                octave = item[2]
                color = Dicts.notesDict[note][0]
                duration = item[3]
                #self.showed+=1
                self.y = data.height/10 * (8-octave)-((ord(note)-97)%97)*(
                                                            data.width/10 /7)
                canvas.create_oval(self.x-10,self.y-10,self.x+10,self.y+10,
                                            width=3,fill=color, outline=color)
                canvas.create_line(self.x+10,self.y+5,
                        self.x-duration*self.tempo,self.y+5,width=2,fill=color)
                #if(self.showed>5):
                self.voice.remove(item)

class Button(object):
    def __eq__(self):
        pass

    def __init__(self,data,x1,y1,x2,y2,text,fill,font=''):
        self.x1,self.y1,self.x2,self.y2 = x1,y1,x2,y2
        self.text,self.fill = text,fill
        self.height = abs(y1-y2)
        self.width = abs(x1-x2)
        self.font = font

    def checkBounds(self,x,y):
        if(x>self.x1 and y>self.y1 and x<self.x2 and y<self.y2):
            return True
        else:
            return False
        pass

    def draw(self,canvas,data):
        if(data.mousex>self.x1 and data.mousey>self.y1 and
                            data.mousex<self.x2 and data.mousey<self.y2):
            canvas.create_rectangle(self.x1,self.y1,self.x2,self.y2,
                                            fill='light grey',width = 0)
        else:
            canvas.create_rectangle(self.x1,self.y1,self.x2,self.y2,
                                            fill=self.fill,width = 0)
        if(self.font == ''):
            textScale = self.width*self.height//400
            canvas.create_text(self.x1+self.width/2,self.y1+self.width/6.5,
                                    text = self.text,font = 'Lato %d'%textScale)
        else:
            canvas.create_text(self.x1+self.width/2,self.y1+self.width/13,
                                    text = self.text,font = self.font)

def listFiles(path): #TAKEN FROM COURSE NOTES
    if (os.path.isdir(path) == False):
        # base case:  not a folder, but a file, so return singleton list
        return [path]
    else:
        # recursive case: it's a folder, return list of all paths
        files = [ ]
        for filename in os.listdir(path):
            files += listFiles(path + "/" + filename)
        return files


####################################
# customize these functions
####################################

def init(data):
    data.generating = False
    data.color1 = '#197BBD'
    data.color2 = '#FF5964'
    data.color3 = '#FFFFEA'
    data.passed,data.pointInSong = False,0
    data.fontScale = data.width*data.height // 20000
    data.margin,data.mainVisited = 10,False #data.height/10
    data.screen = "HomeScreen"
    data.fileOpen = ''
    data.dots = []
    tempo = 100
    for x,y,t,z in [('a',4,.5,0),('b',4,.5,.5),('c',4,.5,1),('d',4,.5,1.5),('e',4,.5,2),('f',4,.5,2.5),('g',4,.5,3),('r',4,.5,3.5)]:
       data.dots.append(Circle(x,y,t,tempo,data))
    data.buttonsMade = 0
    data.mousex,data.mousey = 0,0
    data.buttons = []
    b1 = Button(data,data.width/2-data.margin*10,data.height/2+data.margin*10,data.width/2+data.margin*10,data.height/2+data.margin*16,'Help','red')
    data.buttons.append(b1)
    b2 = Button(data,data.width/2-data.margin*10,data.height/2+data.margin*2,data.width/2+data.margin*10,data.height/2+data.margin*8,'Begin','red')
    data.buttons.append(b2)

def mousePressed(event, data):
    for button in data.buttons:
        if(data.screen == 'HomeScreen'):
            if(button.checkBounds(event.x,event.y) and button.text == 'Begin'):
                data.screen,data.buttons = "Main",[]
            elif(button.checkBounds(event.x,event.y) and button.text == 'Help'):
                data.screen,data.buttons = "Help",[]
        elif(data.screen == 'Help' and button.checkBounds(event.x,event.y)):
            data.screen,data.buttons='Main',[]
        elif(button.checkBounds(event.x,event.y) and button.text == 'Back'):
            data.screen='Main'
        elif(button.checkBounds(event.x,event.y) and button.text == 'Delete'):
            data.screen='Main'
            delete(data.filetovisualize)
        elif(button.checkBounds(event.x,event.y) and button.text == 'Visualize'):
            data.generating = True
            subprocess.Popen(['python','visualizer.py', data.screen,str(data.width),str(data.height),'None','Basic'])
        elif(button.checkBounds(event.x,event.y) and button.text == 'Generate Similar Music (Will Take Time)'):
            temp = Markov('XMLs/'+data.screen+'.xml')
            print(temp[1])
            playMarkov(data.screen+'mkv',temp[0],temp[1])
            subprocess.Popen(['python','visualizer.py', data.screen+'mkv',str(data.width),str(data.height),str(temp),'Basic'])
        elif(button.checkBounds(event.x,event.y) and button.text == 'Visualize (Christmas Theme)'):
            data.generating = True
            subprocess.Popen(['python','visualizer.py', data.screen,str(data.width),str(data.height),'None','Christmas'])


def motion(event,data):
    data.mousex,data.mousey = event.x,event.y
 #  print(data.mousex,data.mousey)

def keyPressed(event, data):
    if(data.screen == "HomeScreen"):

        pass

def timerFired(data):
    if(data.screen == 'Visualize'):
        pass

    if(data.screen == "HomeScreen"):
        pass

def almostEqual(x,y):
    return abs(x-y)<10**(-3)

def playSong(pathtowav):
    subprocess.call(["afplay", pathtowav])

beatUnits={
    'quarter':1,
    'eighth':.5,
    'half':2,
}
def getBeatUnit(data,file):
    xmldoc=minidom.parse('XMLs/'+file+'.xml')
    try:beatUnit=beatUnits[part.getElementsByTagName('beat-unit')[0].childNodes[0].nodeValue]
    except:beatUnit=1
    return beatUnit



def doCircleStuff(data,canvas):
    for button in data.buttons:
        button.draw(canvas,data)
def makeText(data,canvas):
    if(data.generating == True):
            canvas.create_text(data.width/2,7*data.height/10,text='Please Wait, File Generating...',font = 'Lato 25')


def redrawAll(canvas, data):
    if(data.screen == 'Visualize'):
        doCircleStuff(data,canvas)


    elif(data.screen == "HomeScreen"):
        canvas.create_text(data.width/2,data.height/3, anchor = S,text = "Welcome to PyMusic",font = 'Lato %d bold'%data.fontScale)
        doCircleStuff(data,canvas)
        for dot in data.dots:
            dot.move(canvas,data)


    elif(data.screen == "Main" and data.mainVisited == False):
        data.mainVisited = True
        data.dots = []
        data.pointInSong=0
        drawMainScreen(canvas,data)



    elif(data.screen=='Main'):
        canvas.create_rectangle(0,0,data.width/3,data.height,fill=data.color2,width=0)
        #Label(canvas,text='',bg = data.color2).grid(row=1,column=0,sticky=N+W+E+S)
    elif(data.screen == 'Help'):
        helpInstructions = '''
        Welcome to PyMusic, an interactive music visualizing and generating platform.


    There are 3 main screens: the Home Screen, the Song Screen, and the Visualizing Screen


        The HomeScreen allows you to search for sheet music off of the internet and
        download the music to your local disk. Your local files show up on the right
        side of the screen.

        The SongScreen is invoked by clicking on one of the songs you have downloaded.
        On this screen you will have the option to Visualize the song in various themes,
        and generate a song using Markov Chains that is based off of that song.

        The final screen is the visualizing screen. On this screen you can Visualize
        all of the notes in the song as they scroll across the screen.


        '''
        canvas.create_rectangle(0,0,data.width,data.height,fill=data.color3,width=0)
        canvas.create_text(data.width/2,data.height/10,text = data.screen.title(),font = 'Lato 50')
        canvas.create_text(data.width/2,data.height/2,text = helpInstructions,font = 'Lato 25')
        b1 = Button(data,data.width/2-150,data.height-170,data.width/2+150,data.height-120,'Welcome to PyMusic',data.color1,font = 'Lato 22')
        data.buttons.append(b1)
        doCircleStuff(data,canvas)

    else:
        canvas.create_rectangle(0,0,data.width,data.height,fill=data.color3,width=0)
        canvas.create_text(data.width/2,40,text = data.screen.title(),font = 'Lato 50')
        doCircleStuff(data,canvas)
        makeText(data,canvas)


def clearAll(canvas,data):
    for label in canvas.grid_slaves():
        label.grid_forget()

def drawMainScreen(canvas,data):
    initfilesystem()
    #results = [intVar()]*10
    #d = {0:None,1:None,2:None,3:None,4:None,5:None,6:None,7:None,8:None,9:None}
    for i in range(33):
        Label(canvas,text='',bg = data.color1).grid(row=i,column=0,sticky=N+W+E+S)
        Label(canvas,text='',bg = data.color2).grid(row=i,column=1,sticky=N+W+E+S)


    data.checkbuttons = []
    data.buttonsdown = []

    def getResults(query):
        data.searchresults = search(query)
        clearResults()
        def create_checkbutton(name,views,increment):
            var = IntVar()

            cb = Checkbutton(canvas,bg = data.color1, text=name[:40]+'-'+views[:12],command=lambda:buttonsPushed(var),font='Lato 15')
            cb.grid(row=increment+2,column = 0,sticky=W)
            data.buttonsMade+=1
            cb.var = var
            return cb
        data.checkbuttons = [create_checkbutton(name,views,increment) for increment,name,views,url,score in data.searchresults]
        #if(len(data.searchresults)<13):
        #    for i in range(len(data.searchresults),13):
        #        Label(canvas,text='',bg = data.color1).grid(row=i,column=2,sticky=N+W+E+S)

    def buttonsPushed(var):
        var = int(str(var).split('R')[-1])-data.buttonsMade
        #print(var)
        if(var in data.buttonsdown):
            data.buttonsdown.remove(var)
        else:
            data.buttonsdown.append(var)

    def getvals():
        for i in data.buttonsdown:
            try:
                download(data.searchresults[i][3],data.searchresults[i][1], data.searchresults[i][4])
                drawMainScreen(canvas,data)
                Label(canvas,text='File(s) Downloaded').grid(row=18,column=0,sticky=N+W+E+S)
            except:
                drawMainScreen(canvas,data)
                Label(canvas,text='404: Not Found',bg = data.color1).grid(row=18,column=0,sticky=N+W+E+S)

    def clearResults():
        for label in canvas.grid_slaves():
            if int(label.grid_info()["row"]) > 2 and int(label.grid_info()["column"]) == 0 and int(label.grid_info()["row"]) < 15:
                label.grid_forget()
        for i in range(15):
            Label(canvas,text='',bg = data.color1).grid(row=i+2,column=0,sticky=N+W+E+S)


    canvas.columnconfigure(0,minsize=data.width/3)
    #canvas.create_window(0,0,height=data.height,width=data.width/3,anchor = N+W)

    canvas.columnconfigure(1,minsize=2*data.width/3)

    Label(canvas,text = "Search For Songs:",anchor = S,font = 'Lato 26 bold',bg = data.color1).grid(column = 0,row=0,sticky=W+E+N+S)
    Label(canvas, text="Saved Songs:",anchor = S,font = 'Lato 26 bold',bg = data.color2).grid(row=0,column = 1,sticky=W+E+N+S)

    tk.Button(canvas,text="Refresh",highlightbackground=data.color2,command = lambda:drawMainScreen(canvas,data)).grid(row = 0, column = 1, sticky = W)


    tk.Button(canvas,text="Download All Selected",command = lambda:getvals(),highlightbackground=data.color1).grid(row = 20, column = 0, sticky = N+S)

    Label(canvas,bg=data.color1).grid(column=0,row=1,sticky=N+W+E+S)
    e = Entry(canvas,width=25,highlightthickness=0)
    e.grid(column=0,row=1,sticky=W,padx=50)
    b = tk.Button(canvas,text="Search",command=lambda:getResults(e.get()),width=8,highlightbackground=data.color1)
    b.grid(row = 1, column = 0, sticky = E,padx=50)


    ######## END OF LEFT/SEARCH BAR ##########

    files = open("data.txt", "r").readlines()
    data.files = [f.strip() for f in files]
    files = data.files


    def makelabel(name,i):
        files = listFiles('WAV')
        if('WAV/'+name+'.wav' in files):
            l1 = tk.Label(canvas,
                text='✓'+name[:25]+'...' if len(name)>25 else '✓'+name,
                        font='Lato 19 underline',bg = data.color2,fg='#FFFFFF')
        else:
            l1 = tk.Label(canvas,text=name[:25]+'...' if len(name)>25 else name,
                        font='Lato 19 underline',bg = data.color2,fg='#FFFFFF')

        if(i%3== 0):
            l1.grid(row=2*i//3+2,column=1,padx = 30,sticky = W)
        elif(i%3== 1):
            l1.grid(row=2*i//3+2,column=1,padx = 30)
        elif(i%3== 2):
            l1.grid(row=2*i//3+1,column=1,padx = 30,sticky=E)

        l1.bind("<Button-1>",lambda e,name=name:open_page(name))

    def open_page(name):
        data.screen = name
        data.filetovisualize = name
        data.mainVisited = False
        b1 = Button(data,25,data.height-150,175,data.height-120,'Back',
                                                data.color1,font = 'Lato 20')
        b5 = Button(data,data.width-200,data.height-150,data.width-50,
                        data.height-120,'Delete',data.color2,font = 'Lato 20')
        data.buttons.append(b5)
        data.buttons.append(b1)

        b2 = Button(data,data.width/2-100,data.height/6,data.width/2+100,
                                    60+data.height/6,'Visualize',data.color2)
        data.buttons.append(b2)
        b3 = Button(data,data.width/2-260,2*data.height/6,data.width/2+260,80+2*data.height/6,'Generate Similar Music (Will Take Time)',data.color2,font='Lato 28')
        data.buttons.append(b3)
        b4 = Button(data,data.width/2-200,3*data.height/6,data.width/2+200,60+3*data.height/6,'Visualize (Christmas Theme)',data.color2,font='Lato 28')
        data.buttons.append(b4)
        clearAll(canvas,data)

    [makelabel(data.files[i],i) for i in range(len(data.files))]

    def xmlchosen(var):
        var = int(str(var).split('R')[-1])-data.buttonsMade
        #print(var)
        if(var in data.xmlbuttonsdown):
            data.xmlbuttonsdown.remove(var)
        else:
            data.xmlbuttonsdown.append(var)

    def getxmls():

        xmlsToParse = []
        for i in data.xmlbuttonsdown:
            xmlsToParse.append('XMLs/'+files[i]+'.xml')
        if(xmlsToParse!=[]):
            #print('Parsing:'+str(xmlsToParse)+'to:'+e1.get()+'.wav')
            l1 = Label(canvas,text = "Generating File - Please Wait",anchor = S,bg = '#FFFFFF')
            l1.grid(column=1,row=15,sticky=N+W+S+E)
            for f in xmlsToParse:
                temp = Markov(f)
            if(playMarkov('WAV/'+e1.get(),temp[0],temp[1])):
                l1 = Label(canvas,text = "File Created!",anchor = S,bg = '#FFFFFF')
                l1.grid(column=1,row=15,sticky=N+W+S+E)

        else:
            l1 = Label(canvas,text = "Please Select XMLs",anchor = S,bg = '#FFFFFF')
            l1.grid(column=1,row=15,sticky=N+W+S+E)
            #time.sleep(1.5)
            #l1.destroy()




####################################
# use the run function as-is
####################################
def redrawAllWrapper(canvas, data):
    canvas.delete(ALL)
    canvas.create_rectangle(0, 0, data.width, data.height,
                            fill='white', width=0)
    redrawAll(canvas, data)
    canvas.update()
def timerFiredWrapper(canvas, data):
    timerFired(data)
    redrawAllWrapper(canvas, data)
def run(width=300, height=300):
    def redrawAllWrapper(canvas, data):

        canvas.delete(ALL)
        canvas.create_rectangle(0, 0, data.width, data.height,
                                fill='white', width=0)
        redrawAll(canvas, data)
        canvas.update()
        if(data.generating):
            data.generating = False
            time.sleep(15)


    def mousePressedWrapper(event, canvas, data):
        mousePressed(event, data)
        redrawAllWrapper(canvas, data)

    def keyPressedWrapper(event, canvas, data):
        keyPressed(event, data)
        redrawAllWrapper(canvas, data)

    def timerFiredWrapper(canvas, data):
        timerFired(data)
        redrawAllWrapper(canvas, data)
        # pause, then call timerFired again
        canvas.after(data.timerDelay, timerFiredWrapper, canvas, data)
    # Set up data and call init

    class Struct(object): pass
    root = Tk()
    data = Struct()
    data.timerDelay = 20 # milliseconds
    data.delay=20
    data.width = root.winfo_screenwidth()
    data.height = root.winfo_screenheight()
    # create the root and the canvas
    canvas = Canvas(root, width=data.width, height=data.height)
    canvas.pack()
    data.canvas = canvas

    init(data)

    # set up events
    root.bind("<Button-1>", lambda event:
                            mousePressedWrapper(event, canvas, data))
    root.bind("<Key>", lambda event:
                            keyPressedWrapper(event, canvas, data))
    root.bind('<Motion>', lambda event:motion(event,data))

    timerFiredWrapper(canvas, data)

    print('hello')
    # and launch the app
    root.mainloop()  # blocks until window is closed

    print("bye!")

run()
