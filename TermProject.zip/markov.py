#Some code for implementing Markov Chains taken from stack Exchange
#Very basic, needs work

import random
from xmlParser import Parse
from multiinstrument import playMarkov

def Markov(xmlFile):
    data = Parse(xmlFile)
    #print(data)
    avgLen = 0
    for i in range(len(data[0])):
        avgLen +=len(data[0][i])
    avgLen //= i
    sentenceLength = avgLen//3
    final = []
     # create a list of all words in all voices
    for voice in data[0]:
        start = 0
        markov = {i:[] for i in voice}

        pos = 0
        while pos < len(voice) - 1:    # add a word to the word-key's list if it immediately follows that word
            markov[voice[pos]].append(voice[pos+1])
            pos += 1

        seedMatch = {k:v for k,v in zip(range(len(markov)), [i for i in markov])}    # create another dict for the seed to match up with

        seed = random.randint(0, len(seedMatch) - 1)    # randomly pick a starting point

        build = [seedMatch[start]]     # use that word as the first word and starting point
        word = seedMatch[start]

        while len(build) < sentenceLength:
            next_index = random.randint(0, len(markov[word]) - 1)     # randomly pick a word from the last words list.
            next_word = markov[word][next_index]
            build.append(next_word)
            word = next_word


        final.append([i for i in build])
    return (final,data[1])
