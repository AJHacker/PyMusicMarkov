PyMusic is a interactive Music Visualizing and Generating Tool.

-The Packages needed for PyMusic are as follows:

Webscraping:
 - requests
 - BeautifulSoup
 - urllib
 - zipfile
 - shutil

Parsing:
 - xml.dom/minidom

WavFile Maker:
 - scipy
 - numpy

UI/Visualizer:
 - PyGame
 - Tkinter
 - xml.dom
